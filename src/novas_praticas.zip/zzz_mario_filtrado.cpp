#include <playAPC/playapc.h>

#define LARGURA 100
#define ALTURA 100

void ExtraiRGBdeBMP(const char *imagepath, int R[ALTURA][LARGURA], int G[ALTURA][LARGURA], int B[ALTURA][LARGURA]){

    unsigned char header[54]; // Todo BMP tem um cabe�alho com 54 posi��es
    unsigned int dataPos;     // Posi��o do ponteiro onde os dados de RGB de fato come�am
    unsigned int imageSize;   // = width*height*3 = largura * altura * (Matriz R + Matriz G + Matriz B)
    unsigned int width;
    unsigned int height;
    // Imagem propriamente dita
    unsigned char * data;
    int k = 0;

    // Abrindo o arquivo
    FILE * file = fopen(imagepath,"rb");
    if (!file){
        printf("Erro ao abrir imagem\n");
        exit(0);
    }
    if ( fread(header, 1, 54, file) != 54 ){ // Se o arquivo for menor que o cabe�alho do bmp, problema
        printf("Isso e qualquer coisa, menos uma imagem bmp\n");
        exit(0);
    }
    if ( header[0] != 'B' && header[1] != 'M' ){
        printf("Tipo incorreto de imagem. Eu so consigo ler BMP\n");
        exit(0);
    }
    // Pega informa��es do cabe�alho
    //Achei na internet :D
    dataPos    = *(int*)&(header[0x0A]);
    imageSize  = *(int*)&(header[0x22]);
    width      = *(int*)&(header[0x12]);
    height     = *(int*)&(header[0x16]);

    // Se esse bmp for porco e n�o tiver as informa��es corretas
    if (imageSize == 0)
        imageSize = width*height*3; // Largura * altura * RGB
    if (dataPos == 0)
        dataPos = 54; // Assim que o cabe�alho termina, provavelmente deve come�ar a imagem

    // Vetor com dados da imagem
    data = (unsigned char*)malloc(imageSize * sizeof(unsigned char));

    // L� o arquivo inteiro, de uma vez, PAH
    fread(data,1,imageSize,file);

    //Alguns BMP est�o em BGR
    for(int i = 0; i < LARGURA; i++){
        for(int j = 0; j < ALTURA; j++){
            B[j][i] = data[k];
            k++;

            G[j][i] = data[k];
            k++;

            R[j][i] = data[k];
            k++;
        }
    }
}

int main(){
    int R[LARGURA][ALTURA], G[LARGURA][ALTURA], B[LARGURA][ALTURA];
    int Raux[LARGURA + 2][ALTURA + 2], Gaux[LARGURA + 2][ALTURA + 2], Baux[LARGURA + 2][ALTURA + 2];
    int Rf[LARGURA + 2][ALTURA + 2], Gf[LARGURA + 2][ALTURA + 2], Bf[LARGURA + 2][ALTURA + 2];
    int soma;
    int mfiltro = 8;
    Ponto p;

    //inicializa matriz aux
    for(int i = 0; i < LARGURA + 2; i++){
        for(int j = 0; j < LARGURA + 2; j++){
            Raux[i][j] = 0;
            Gaux[i][j] = 0;
            Baux[i][j] = 0;

            Rf[i][j] = 0;
            Gf[i][j] = 0;
            Bf[i][j] = 0;
        }
    }

    ExtraiRGBdeBMP("Mario.bmp", R, G, B);

    AbreJanela(300, 300, "Marios");
    //PintarFundo(255, 255, 255);

    //Passa as cores para aux
    for(int i = 1; i < LARGURA + 1; i++){
        for(int j = 1; j < ALTURA + 1; j++){
            Raux[i][j] = R[i - 1][j - 1];
            Gaux[i][j] = G[i - 1][j - 1];
            Baux[i][j] = B[i - 1][j - 1];
        }
    }

    //Realiza filtragem
    for(int i = 1; i < LARGURA + 1; i++){
        for(int j = 1; j < ALTURA + 1; j++){
            soma = 0;
            soma +=     Raux[i-1][j-1] + Raux[i-1][j] + Raux[i-1][j+1]
                    +   Raux[i][j-1] + Raux[i][j] + Raux[i][j+1]
                    +   Raux[i+1][j-1] + Raux[i+1][j] + Raux[i+1][j+1];
            Rf[i][j] = soma/mfiltro;

            soma = 0;
            soma +=     Gaux[i-1][j-1] + Gaux[i-1][j] + Gaux[i-1][j+1]
                    +   Gaux[i][j-1] + Gaux[i][j] + Gaux[i][j+1]
                    +   Gaux[i+1][j-1] + Gaux[i+1][j] + Gaux[i+1][j+1];
            Gf[i][j] = soma/mfiltro;

            soma = 0;
            soma +=     Baux[i-1][j-1] + Baux[i-1][j] + Baux[i-1][j+1]
                    +   Baux[i][j-1] + Baux[i][j] + Baux[i][j+1]
                    +   Baux[i+1][j-1] + Baux[i+1][j] + Baux[i+1][j+1];
            Bf[i][j] = soma/mfiltro;

        }
    }

    p.x = -100;
    for(int i = 1; i < ALTURA + 1; i++){
        p.y = -50;
        for(int j = 1; j < LARGURA + 1; j++){
            CriaQuadrado(1, p);
            Pintar(Raux[i][j], Gaux[i][j], Baux[i][j]);

            p.y++;
        }
        p.x++;
    }

    p.x = 0;
    for(int i = 1; i < ALTURA + 1; i++){
        p.y = -50;
        for(int j = 1; j < LARGURA + 1; j++){
            CriaQuadrado(1, p);
            Pintar(Rf[i][j], Gf[i][j], Bf[i][j]);

            p.y++;
        }
        p.x++;
    }

    Desenha();

}
