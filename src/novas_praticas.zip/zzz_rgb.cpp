#include <playAPC/playapc.h>
#include <stdio.h>
#include <math.h>

#define QTD 22

int main(){
    int R[QTD], G[QTD], B[QTD];
    int Rf[QTD], Gf[QTD], Bf[QTD];
    int mfiltro = 3;
    int somaaux[3];
    Ponto p, pf;
    float mse = 0, distancia;

    R[0] = 0; R[QTD-1] = 0;
    G[0] = 0; G[QTD-1] = 0;
    B[0] = 0; B[QTD-1] = 0;

    for(int i = 1; i < QTD-1; i++){
        /*printf("\n****\nElemento n%d\n****\n", i);

        printf("\nInsira componente R:");
        scanf("%d", &R[i]);
        printf("\nInsira componente G:");
        scanf("%d", &G[i]);
        printf("\nInsira componente B:");
        scanf("%d", &B[i]);*/

        R[i] = rand()%255;
        G[i] = rand()%255;
        B[i] = rand()%255;

    }

    for(int i = 1; i < QTD - 1; i++){
        somaaux[0] = 0;
        somaaux[1] = 0;
        somaaux[2] = 0;
        for(int j = -1; j < mfiltro - 1; j++){
            somaaux[0] += R[(i + j)];
            somaaux[1] += G[(i + j)];
            somaaux[2] += B[(i + j)];
        }
        Rf[i] = somaaux[0]/mfiltro;
        Gf[i] = somaaux[1]/mfiltro;
        Bf[i] = somaaux[2]/mfiltro;

    }

    AbreJanela(400, 400, "Filtragem Media Movel");
    PintarFundo(255, 255, 255);
    MostraPlanoCartesiano(10);

    p.x = -20;
    p.y = 90;

    pf.x = 10;
    pf.y = 90;
    for(int i = 1; i < QTD - 1; i++){
        CriaQuadrado(10, p);
        Pintar(R[i], G[i], B[i]);
        p.y -= 10;

        CriaQuadrado(10, pf);
        Pintar(Rf[i], Gf[i], Bf[i]);
        pf.y -= 10;

        /*printf("\n****\nQuadrado %d\n****\n", i);
        printf("R[%d] = %d \t R[%d] = %d \t R[%d] = %d\n", i-1, R[i-1], i, R[i], i+1, R[i+1]);
        printf("G[%d] = %d \t G[%d] = %d \t G[%d] = %d\n", i-1, G[i-1], i, G[i], i+1, G[i+1]);
        printf("B[%d] = %d \t B[%d] = %d \t B[%d] = %d\n", i-1, B[i-1], i, B[i], i+1, B[i+1]);
        printf("\n");*/

        mse +=      pow(R[i] - Rf[i], 2) + pow(R[i] - Gf[i], 2) + pow(R[i] - Bf[i], 2)  //distancia euclidiana de R
                +   pow(G[i] - Rf[i], 2) + pow(G[i] - Gf[i], 2) + pow(G[i] - Bf[i], 2) //distancia euclidiana de G
                +   pow(B[i] - Rf[i], 2) + pow(B[i] - Gf[i], 2) + pow(B[i] - Bf[i], 2); //distancia euclidiana de B

    }
    mse = (sqrt(mse))/(QTD-2);

    printf("O erro medio quadrado e %.2f\n", mse);

    Desenha();
}
